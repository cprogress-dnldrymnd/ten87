<?php

include_once OBSIUS_CORE_INC_PATH . '/background-text/helper.php';
