<?php

include_once OBSIUS_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/simple/simple.php';
