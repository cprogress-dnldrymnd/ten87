<?php

include_once OBSIUS_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-obsiuscore-blog-list-widget.php';
include_once OBSIUS_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-obsiuscore-simple-blog-list-widget.php';
