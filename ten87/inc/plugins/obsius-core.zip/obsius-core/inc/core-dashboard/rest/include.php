<?php

include_once OBSIUS_CORE_INC_PATH . '/core-dashboard/rest/class-obsiuscore-dashboard-rest-api.php';
