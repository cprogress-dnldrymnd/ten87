<?php

include_once OBSIUS_CORE_INC_PATH . '/core-dashboard/sub-pages/system-info/class-obsiuscore-dashboard-system-info-page.php';
