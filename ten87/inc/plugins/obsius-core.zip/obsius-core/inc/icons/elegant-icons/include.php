<?php

include_once OBSIUS_CORE_INC_PATH . '/icons/elegant-icons/class-obsiuscore-elegant-icons-pack.php';
