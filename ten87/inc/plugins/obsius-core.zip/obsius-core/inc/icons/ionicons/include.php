<?php

include_once OBSIUS_CORE_INC_PATH . '/icons/ionicons/class-obsiuscore-ionicons-pack.php';
