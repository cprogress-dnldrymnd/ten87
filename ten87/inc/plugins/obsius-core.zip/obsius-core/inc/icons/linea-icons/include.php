<?php

include_once OBSIUS_CORE_INC_PATH . '/icons/linea-icons/class-obsiuscore-linea-icons-pack.php';
