<?php

if ( qode_framework_is_installed( 'elementor' ) ) {
	include_once OBSIUS_CORE_PLUGINS_PATH . '/elementor/helper.php';
	include_once OBSIUS_CORE_PLUGINS_PATH . '/elementor/class-obsiuscore-elementor-section-handler.php';
}
