<?php

include_once OBSIUS_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/class-obsiuscore-instagram-list-shortcode.php';
