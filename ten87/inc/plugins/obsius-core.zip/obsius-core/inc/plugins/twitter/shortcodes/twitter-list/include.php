<?php

include_once OBSIUS_CORE_PLUGINS_PATH . '/twitter/shortcodes/twitter-list/class-obsiuscore-twitter-list-shortcode.php';
