<?php

include_once OBSIUS_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/preview-product-slider/variations/info-left/info-left.php';
