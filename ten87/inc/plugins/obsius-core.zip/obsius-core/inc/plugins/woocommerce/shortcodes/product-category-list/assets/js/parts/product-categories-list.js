(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.obsius_core_product_category_list                    = {};
	qodefCore.shortcodes.obsius_core_product_category_list.qodefMasonryLayout = qodef.qodefMasonryLayout;
	qodefCore.shortcodes.obsius_core_product_category_list.qodefSwiper        = qodef.qodefSwiper;

})( jQuery );
