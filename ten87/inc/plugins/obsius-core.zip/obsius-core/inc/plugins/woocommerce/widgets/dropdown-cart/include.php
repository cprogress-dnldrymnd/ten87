<?php

include_once OBSIUS_CORE_PLUGINS_PATH . '/woocommerce/widgets/dropdown-cart/class-obsiuscore-woocommerce-dropdown-cart-widget.php';
