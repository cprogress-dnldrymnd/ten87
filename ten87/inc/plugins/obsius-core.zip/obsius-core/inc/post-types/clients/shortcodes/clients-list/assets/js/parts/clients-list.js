(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.obsius_core_clients_list             = {};
	qodefCore.shortcodes.obsius_core_clients_list.qodefSwiper = qodef.qodefSwiper;

})( jQuery );
