<?php

include_once OBSIUS_CORE_CPT_PATH . '/class-obsiuscore-custom-post-types.php';
