<?php

class QodeFrameworkFieldWidgetImage extends QodeFrameworkFieldWidgetType {

    public function render() { ?>
        <?php $hide_class = empty( $this->params['value'] ) ? 'qodef-hide' : ''; ?>
        <span class="qodef-image-uploader" data-file="no">
            <span class="qodef-image-thumb">
				<?php if ( $this->multiple == 'yes' ) { ?>
                    <ul class="clearfix <?php echo esc_attr( $hide_class ); ?>">
						<?php
                        if ( $this->params['value'] !== '' ) {
                            $images_array = explode( ',', $this->params['value'] );
                            foreach ( $images_array as $image_id ):
                                $image_src = wp_get_attachment_image_src( $image_id, 'thumbnail', false );
                                echo '<li style="float:left;"><img src="' . esc_url( $image_src[0] ) . '" alt="' . esc_attr__( "Image Thumbnail", "qode-framework" ) . '" /></li>';
                            endforeach;
                        }
                        ?>
					</ul>
                <?php } else {
                    if ( $this->params['value'] !== '' ) {
                        $image_src = wp_get_attachment_image_src( $this->params['value'], 'thumbnail', false ); ?>
                        <img class="qodef-single-image" src="<?php echo esc_url( $image_src[0] ); ?>" alt="<?php esc_attr_e( 'Image Thumbnail', 'qode-framework' ); ?>"/>
                    <?php }
                } ?>
            </span>
			<?php if ( $this->multiple == 'yes' ) { ?>
                <input type="text" class="qodef-field qodef-image-upload-id widefat" id="<?php echo esc_attr( $this->params['id'] ); ?>" name="<?php echo esc_attr( $this->params['name'] ); ?>" value="<?php echo esc_attr( $this->params['value'] ); ?>"/>
                <span class="qodef-field-description"><?php esc_html_e("Add images id for your image gallery widget, separate id\'s with comma
", "qode-framework"); ?></span>
            <?php } else { ?>
                <span class="qodef-image-meta-fields <?php echo esc_attr( $hide_class ); ?>">
                    <input type="hidden" class="qodef-field qodef-image-upload-id" id="<?php echo esc_attr( $this->params['id'] ); ?>" name="<?php echo esc_attr( $this->params['name'] ); ?>" value="<?php echo esc_attr( $this->params['value'] ); ?>"/>
                </span>
                <a class="button button-secondary qodef-image-upload-btn" href="javascript:void(0)" data-frame-title="<?php esc_attr_e( 'Select Image', 'qode-framework' ); ?>" data-frame-button-text="<?php esc_attr_e( 'Select Image', 'qode-framework' ); ?>"><?php esc_html_e( 'Upload', 'qode-framework' ); ?></a>
                <a href="javascript: void(0)" class="button button-secondary qodef-image-remove-btn qodef-hide"><?php esc_html_e( 'Remove', 'qode-framework' ); ?></a>
            <?php } ?>
        </span>
    <?php }
}
